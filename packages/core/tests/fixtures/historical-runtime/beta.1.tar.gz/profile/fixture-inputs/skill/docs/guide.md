Historical guide bytes
