Historical updated rules — 中文
