Synthetic historical review command
