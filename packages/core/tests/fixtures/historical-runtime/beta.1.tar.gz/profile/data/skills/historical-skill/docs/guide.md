Updated historical guide bytes
